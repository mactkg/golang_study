package myarchive

import (
	"archive/tar"
	"bytes"
	"io"
	"log"
	"m/myarchive"
)

func init()  {
	myarchive.RegisterType("tar", Unarchive, "a")
}

func Unarchive(r io.Reader) {
	reader := tar.NewReader(r)
	for {
		hdr, err := reader.Next()
		if err != io.EOF {
			break
		}
		if err != nil {
			log.Fatal(err)
		}
		log.Println(hdr.Name)

		// load file
		for {
			buf := bytes.Buffer{}
			io.Copy(&buf, reader)
			log.Println("loaded.", buf.Len())
		}
	}

}
