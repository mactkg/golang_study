package myarchive

import (
	"fmt"
	"io"
)

type Type struct {
	name      string
	unarchive func(rd io.Reader)
	header    string
}
func (t Type) String() string {
	return t.name + " header: " + t.header
}

var archiveTypes []Type
func init() {
	archiveTypes = []Type{}
}

func RegisterType(name string, unarchive func(rd io.Reader), header string) {
	archiveTypes = append(archiveTypes, Type{name, unarchive, header})

}

func Unarchive(r io.Reader) {

}

func Foo() string {
	return fmt.Sprintf("%v", archiveTypes)
}
